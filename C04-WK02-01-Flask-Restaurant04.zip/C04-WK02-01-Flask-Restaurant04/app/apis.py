from ast import Store, dump
from email import message
from typing import Dict
from app import application
from flask import jsonify, Response, session
from app.models import *
from app import *
import uuid
import datetime
from marshmallow import Schema, fields
from flask_restful import Resource, Api
from flask_apispec.views import MethodResource
from flask_apispec import marshal_with, doc, use_kwargs
import json


class SignUpRequest(Schema):
    username = fields.Str(default="username")
    password = fields.Str(default="password")
    name = fields.Str(default="name")
    level = fields.Int(default=0)


class LoginRequest(Schema):
    username = fields.Str(default="username")
    password = fields.Str(default="password")


class APIResponse(Schema):
    message = fields.Str(default="Successful")


class AddVendorRequest(Schema):
    user_id = fields.Str(default="user_id")


class ItemsListResponse(Schema):
    items = fields.List(fields.Dict())


class VendorListResponse(Schema):
    vendors = fields.List(fields.Dict())


class AddItemsRequest(Schema):
    item_id = fields.Str(default="item_id")
    item_name = fields.Str(default="item_name")
    restaurant_name = fields.Str(default="restaurant_name")
    available_quantity = fields.Str(default="available_quantity")
    unit_price = fields.Str(default="unit_price")
    calories_per_gm = fields.Str(default="calories_per_gm")


class PlaceOrderRequest(Schema):
    order_id = fields.Str(default="order_list")


class ItemsOrderList(Schema):
    items = fields.List(fields.Dict())


#  Restful way of creating APIs through Flask Restful
class SignUpAPI(MethodResource, Resource):
    @doc(description='Sign Up API', tags=['SignUp APi'])
    @use_kwargs(SignUpRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            user = User(
                user_id=uuid.uuid4(),
                name=kwargs['name'],
                username=kwargs['username'],
                password=kwargs['password'],
                level=kwargs['level'])
            db.session.add(user)
            db.session.commit()
            return APIResponse().dump(dict(message="User Successfully SignedUp"))

        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(message=f"Failed Registering User: {str(Error1)}"))


api.add_resource(SignUpAPI, '/signup')
docs.register(SignUpAPI)


class LoginAPI(MethodResource, Resource):
    @doc(description='Login API', tags=['Login API'])
    @use_kwargs(LoginRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            user = User.query.filter_by(username=kwargs['username'], password=kwargs["password"]).first()
            if user:
                print('Logged in Successfully')
                session['user_id'] = user.user_id
                print(f'User id : {str(session["user_id"])}')
                return APIResponse().dump(dict(message='User Successfully LoggedIn')), 200
            else:
                return APIResponse().dump(dict(message="User Not Registered")), 404
        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(message=f'User Not Able To Login : {str(Error1)}')), 400


api.add_resource(LoginAPI, '/login')
docs.register(LoginAPI)


class LogoutAPI(MethodResource, Resource):
    @doc(description='Logout API', tags=['Logout API'])
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            if session['user_id']:
                session['user_id'] = None
                print('User LoggedOut Successfully')
                return APIResponse().dump(dict(message='User Suuccessfully Logged Out')), 200
            else:
                print('User Not Found')
                return APIResponse().dump(dict(message='Trouble logging out the user')), 404
        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(message=f"Not able to logout the user : {str(Error1)}")), 400


api.add_resource(LogoutAPI, '/logout')
docs.register(LogoutAPI)


class AddVendorAPI(MethodResource, Resource):
    @doc(description='AddVendor Api', tags=['Add Vendor Api'])
    @use_kwargs(AddVendorRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                if user_type == 2:
                    vendor_user_id = kwargs['user_id']
                    print(vendor_user_id)
                    user = User.query.filter_by(user_id=vendor_user_id).first()
                    print(user.level)
                    User.level = 1
                    db.session.commit()
                    return APIResponse().dump(dict(message="Vendor Successfully Added")), 200
                else:
                    print("Unable To Add Vendor")
                    return APIResponse().dump(dict(message="Trouble Adding Vendor")), 404
            else:
                print('user not found')
        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(message=f"Unable to Add Vendor : {str(Error1)}")), 400


api.add_resource(AddVendorAPI, '/add_vendor')
docs.register(AddVendorAPI)


class GetVendorsAPI(MethodResource, Resource):
    @doc(description='Vendor List Api', tags=['Vendor Api'])
    @marshal_with(VendorListResponse)
    def get(self, kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                if session['level'] == 2:
                    user = User.query.filter_by(username=kwargs['username'], password=kwargs["password"]).first()
                    vendors = user.query.all()
                    vendor_list = list()
                    for vendor in vendors:
                        vendor_dict = {'vendor_id': user.user_id, 'vendor_name': user.username, 'store': vendors.store,
                                       'Items': Item.item_name}

                        vendor_list.append(vendor_dict)
                    print(vendor_list)
                    return VendorListResponse().dump(dict(vendors=vendor_list)), 200
                else:
                    print('user not found')
            else:
                print("Vendor Not Found")
                return VendorListResponse().dump(dict(message="Not Able to find Vendors")), 404
        except Exception as Error1:
            print(str(Error1))
            return VendorListResponse().dump(dict(message=f"Vendors Not Found: {str(Error1)}")), 400


api.add_resource(GetVendorsAPI, '/list_vendors')
docs.register(GetVendorsAPI)


class AddItemAPI(MethodResource, Resource):
    @doc(description='Add Item Api', tags=['AddItem Api'])
    @use_kwargs(AddItemsRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session["user_id"]
                user_type = User.query.filter_by(user_id=user_id).first().level
                if user_type == 1:
                    item = Item(
                        uuid.uuid4(),
                        session["user_id"],
                        kwargs["item_id"],
                        kwargs["item_name"],
                        kwargs["restaurant_name"],
                        kwargs["available_quantity"],
                        kwargs["unit_price"],
                        kwargs["calories_per_gm"]
                    )
                    db.session.add(item)
                    db.session.commit()
                    print("Item Added SuccessFully")
                    return APIResponse().dump(dict(message="Item Added Successfully")), 200
                else:
                    return APIResponse().dump(dict(message='Unable to add item')), 400
            else:
                return APIResponse().dump(dict(message='User not found')), 404
        except  Exception as Error1:
            return APIResponse().dump(dict(message=f"unable to print vendors: {str(Error1)}")), 400


api.add_resource(AddItemAPI, '/add_item')
docs.register(AddItemAPI)


class ListItemsAPI(MethodResource, Resource):
    @doc(description='List Items Api', tags=['list items Api'])
    @marshal_with(ItemsListResponse)
    def get(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                print(user_id)

                if user_type == 2:
                    items = User.query.filter_by(username=kwargs['username'], password=kwargs["password"]).first()
                    items = Item.query.all()
                    items_list = list()
                    for items in Item:
                        items_dict = {'item_id': items.item_id, 'vendor_id': items.vendor_id, 'store': items.store,
                                      'item_name': items.item_name, 'item_quantity': items.available_quantity}

                        items_list.append(items_dict)
                    print(items_list)
                    return APIResponse().dump(dict(message="Items List printed successfully")), 200
                else:
                    return APIResponse().dump(dict(message="Unable to list Items")), 400
            else:
                print('unable to print items list'), 404
        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(message=f'Unavle to print items : {str(Error1)}')), 400


api.add_resource(ListItemsAPI, '/list_items')
docs.register(ListItemsAPI)


# start here
class CreateItemOrderAPI(MethodResource, Resource):
    @doc(description='Create Item Order Api', tags=['order Api'])
    @use_kwargs(ItemsOrderList, location='json')
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                print(user_type)
                if user_type == 0:
                    item_id = kwargs['item_id']
                    quantity_to_buy = kwargs['quantity_to_by']
                    if quantity_to_buy <= 0:
                        return APIResponse().dump(dict(message='Quantity must be More than 0')), 400
                    items = Item.query.filter_by(item_id=item_id, is_active=1).first()
                    if items.available_quantity < quantity_to_buy:
                        return APIResponse().dump(dict(message='not available quanity should be lessthan available '
                                                               'quantity'))
                    items.available_quantity = items.available_quantity - quantity_to_buy
                    order_items = OrderItems(
                        id=id,
                        order_id=uuid.uuid4(),
                        user_id=session['user_id'],
                        item_id=item_id,
                        quantity=quantity_to_buy,
                        is_active=1,
                        created_ts=datetime.datetime.utcnow()
                    )
                    db.session.commit()
                    order = Order.query.filter_by(user_id=session['user_id'], item_id=item_id).first()
                    if not order:
                        order = Order(
                            order_id=uuid.uuid4(),
                            user_id=session['user_id'],
                            total_amount=items.unit_price,
                            is_active=1,
                            created_ts=datetime.datetime.utcnow()
                        )
                        db.session.add(order)
                    else:
                        order.quantity = order.quantity + quantity_to_buy

                    db.session.commit()

                    return APIResponse().dump(dict(message='Order Placed Successfully'))
                else:
                    return APIResponse().dump(dict(message='Unable to print Item orders')), 400
            else:
                print('unable to print orders'), 404
        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(messgae=f'Unable to print ItemsOrder: {str(Error1)}')), 400


api.add_resource(CreateItemOrderAPI, '/create_items_order')
docs.register(CreateItemOrderAPI)


class PlaceOrderAPI(MethodResource, Resource):
    @doc(description='Place Order Api', tags=['Order Api'])
    @use_kwargs(PlaceOrderRequest, location='json')
    @marshal_with(APIResponse)
    def post(self, post):
        try:
            order_list = list()
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                if user_type == 0:
                    order_id = Order.query.all()
                    for order in Order:
                        print(order)
                    print("order placed successfully")
                    return APIResponse().dump(dict(messgae='order placed successfully')), 200
                else:
                    return APIResponse().dump(dict(message='Unable to place order')), 400
            else:
                print('unable to place order user not logged in'), 404
        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(message=f'unable to place order: {str(Error1)}')), 400


api.add_resource(PlaceOrderAPI, '/place_order')
docs.register(PlaceOrderAPI)


class ListOrdersByCustomerAPI(MethodResource, Resource):
    @doc(description='List Orders By Customer Api', tags=['Order Api'])
    def get(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                customer_order = Order.query.filter_by(user_id=['user_id'], is_active=1)
                customer_order_list = list()
                if user_id == 1:
                    for items in customer_order:
                        items_dict = {'item_id': items.item_id,'item_name': items.item_name, 'order_id': Order.order_id}
                    print(customer_order)
                    return APIResponse().dump(dict(message="printing all orders By customers")), 200
                else:
                    print("Unable to print orders"), 400
            else:
                return APIResponse().dump(dict(message='user not found')), 404
        except Exception as Error1:
            print(str(Error1))
            return APIResponse().dump(dict(message=f"User not found: {str(Error1)}")), 400


api.add_resource(ListOrdersByCustomerAPI, '/list_orders')
docs.register(ListOrdersByCustomerAPI)


class ListAllOrdersAPI(MethodResource, Resource):
    @doc(description="List all orders Api", tags=['Order Api'])
    def get(self, **kwargs):
        try:
            if session["user_id"]:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                print(user_id)

                if user_id == 2:
                    orders = Order.query.filter_by(is_active=1)
                    print(orders)
                    return APIResponse().dump(dict(message=f"Printing all the orders: {orders}"))
                else:
                    print("unable to print order")
            else:
                print('Unable to List all Orders')
        except Exception as Error1:
            return APIResponse().dump(dict(message=f"User Not Found: {str(Error1)}"))


api.add_resource(ListAllOrdersAPI, '/list_all_orders')
docs.register(ListAllOrdersAPI)
